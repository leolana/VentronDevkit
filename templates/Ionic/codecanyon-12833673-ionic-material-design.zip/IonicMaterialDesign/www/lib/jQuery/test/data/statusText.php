<?php

header( "HTTP/1.0 $_GET[status] $_GET[text]" );

?>